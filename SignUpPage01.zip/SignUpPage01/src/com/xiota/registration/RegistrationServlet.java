package com.xiota.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistrationServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		String url = "jdbc:mysql://localhost:3306/qpsxiota?useSSL=false";
//		String username = "root";jdbc:postgresql://192.168.11.249:5432/postgres
//		String password1 = "chinna";postgres1234
		
		String url = "jdbc:postgresql://113.193.50.6:5432/xiota?useSSL=false";
		String username = "postgres";
		String password1 = "Q!aoe@_2405*";
		
		Connection cn = null;
		PreparedStatement ps = null;
		
		String uname = request.getParameter("name");
		String uemail = request.getParameter("email");
		String upwd = request.getParameter("pass");
		String umobile = request.getParameter("contact");
		
		RequestDispatcher dispatcher= null;
		
		PrintWriter out = response.getWriter();
//		out.print(uname+"\n");
//		out.print(uemail+"\n");
//		out.print(umobile+"\n");
//		out.print(upwd+"\n");
		
		
		try {
			Class.forName("org.postgresql.Driver");

			cn = DriverManager.getConnection(url,username,password1);
			ps = cn.prepareStatement("insert into users(uname,upwd,uemail,umobile) values(?,?,?,?)");
			
			ps.setString(1, uname);
			ps.setString(2, upwd);
			ps.setString(3, uemail);
			ps.setString(4, umobile);
			
			int count = ps.executeUpdate();
			
			dispatcher = request.getRequestDispatcher("registration.jsp");
			
			if(count>0)
			{
//				out.print("<h1> The Data is inserted successfully</h1>");
				request.setAttribute("status", "success");
			}
			else {
//				out.print("<h1>The data is nor inserted successfully</h1>");
				request.setAttribute("status", "fail");
			}
			dispatcher.forward(request, response);
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception: "+e.toString());
		}
		finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(cn!=null) {
				try {
					cn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

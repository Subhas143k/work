package com.xiota.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginAdmin")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//This is fro the mysql....
//		String url = "jdbc:mysql://localhost:3306/qpsxiota?useSSL=false";
//		String username = "";
//		String password1 = "";
		
		//This is for the postgress sql connection...
//		String url = "jdbc:postgresql://113.193.50.6:5432/xiota?useSSL=false";
//		String username = "postgres";
//		String password1 = "Q!aoe@_2405*";
		
		String url = "jdbc:postgresql://113.193.50.6:5432/xiota?useSSL=false";
		String username = "postgres";
		String password1 = "Q!aoe@_2405*";
		
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
	
		String uemail = request.getParameter("adminEmail");
		System.out.println("uemail : "+uemail);
		String upwd = request.getParameter("adminPassword");
		System.out.println("upwd: "+upwd);
		
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher= null;
		System.out.println("session : "+session);
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection(url,username,password1);
			ps = cn.prepareStatement("select * from users where uemail=? and upwd=?");
			
			ps.setString(1, uemail);
			ps.setString(2, upwd);
			
			rs = ps.executeQuery();	
			
			if(rs.next())
			{
//				System.out.println("Successss");
				session.setAttribute("name", rs.getString("uname"));
				dispatcher = request.getRequestDispatcher("homePage.jsp");
			}
			else {
//				System.out.println("Faillll");
				request.setAttribute("status", "failed");
				dispatcher = request.getRequestDispatcher("loginAdmin.jsp");
			}
			dispatcher.forward(request, response);
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(cn!=null) {
				try {
					cn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
